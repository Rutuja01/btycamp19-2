package com.example.myapplication5;

import android.app.Application;
import android.util.Log;

import com.google.firebase.FirebaseApp;

public class myapplication5 extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d("Application class","onCreate");
        FirebaseApp.initializeApp(this);

    }
}
