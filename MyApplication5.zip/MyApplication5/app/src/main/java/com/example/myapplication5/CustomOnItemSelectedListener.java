package com.example.myapplication5;

class CustomOnItemSelectedListener {
}
