package com.example.myapplication5;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
//import android.view.Menu;
//import android.app.Activity;
import android.view.View;
import android.widget.Button;

//
import android.app.PendingIntent;
import android.content.Intent;
import android.telephony.SmsManager;
import android.view.View.OnClickListener;
//
import android.widget.EditText;
import android.widget.Toast;

public class Activity3 extends AppCompatActivity {
    Button submit;
    EditText noofpeople;
    EditText mobil_no,message;
    Button sendsms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {



        super.onCreate(savedInstanceState);                          //1
        setContentView(R.layout.activity_3);
        noofpeople = (EditText) findViewById(R.id.numpeople);
        submit = (Button) findViewById(R.id.Submit);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override                                                //1 a
            public void onClick(View v) {
                if (noofpeople.getText().toString().isEmpty()
                ) {
                    Toast.makeText(getApplicationContext(), "Enter the Data", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "No of people to be served -  " + noofpeople.getText().toString(), Toast.LENGTH_SHORT).show();
                }
            }
        });





            super.onCreate(savedInstanceState);                      //2
            setContentView(R.layout.activity_main);

            mobil_no=(EditText)findViewById(R.id.mob);
            message=(EditText)findViewById(R.id.msg);
            sendsms=(Button)findViewById(R.id.sendsms);

//Performing action on button click
            sendsms.setOnClickListener(new OnClickListener() {

                @Override                                              //2 a
                public void onClick(View arg0) {
                    String no=mobil_no.getText().toString();
                    String msg=message.getText().toString();

//Getting intent and PendingIntent instance
                    Intent intent=new Intent(getApplicationContext(),MainActivity.class);
                    PendingIntent pi=PendingIntent.getActivity(getApplicationContext(), 0, intent,0);

//Get the SmsManager instance and call the sendTextMessage method to send message
                    SmsManager sms=SmsManager.getDefault();
                    sms.sendTextMessage(no, null, msg, pi,null);

                    Toast.makeText(getApplicationContext(), "Message Sent successfully!",
                            Toast.LENGTH_LONG).show();
                }
            });
    }





    }


                

