package com.example.myapplication5;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
//import android.app.Activity;
import android.content.Intent;
//import android.net.Uri;
import android.widget.Button;
import android.view.View;
import android.view.View.OnClickListener;
//import android.widget.Button;


//import java.util.ArrayList;
//import java.util.List;

//import android.app.Activity;
//import android.os.Bundle;
//import android.view.View;
//import android.widget.ArrayAdapter;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.Spinner;
//import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class MainActivity extends AppCompatActivity {
    Button button;


    // private Spinner spinner1; //spinner2;
    private Button btnDonate;
    private Button btnalreadyadoner;
    //  private Button websiteButton;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FirebaseApp.initializeApp(this);


       /* spinner1 = (Spinner) findViewById(R.id.spinner1);
        // get the selected dropdown list value
        spinner1 = (Spinner) findViewById(R.id.spinner1);*/
        btnDonate = (Button) findViewById(R.id.btnDonate);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("users").child("1234567890").child("name");

        myRef.setValue("Hello, World!");


       // btnDonate = findViewById(R.id.btnDonate);
        btnDonate.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, Activity2.class));
            }
        });
       // btnalreadyadoner = findViewById(R.id.btnaldo);
        btnalreadyadoner = findViewById(R.id.btnaldo);

        btnalreadyadoner.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, Activity3.class));

            }
        });







       /* websiteButton = findViewById(R.id.website_button);
        websiteButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://robinhoodarmy.com"));
                startActivity(browserIntent);
            }
        });*/


    }


}